<link type="text/css" rel="Stylesheet" href="Views/Stylesheets/bootstrap.min.css"/>
<link type="text/css" rel="Stylesheet" href="Views/Stylesheets/stylesheet_index.css"/>
<link type="text/css" rel="Stylesheet" href="Views/Stylesheets/stylesheet_default.css"/>


<div class="container body-content">
		<hr/>
        <footer style="font-family: Verdana;">
 		<p>&copy; <!-- Php Section to Fetch Current Year --> <?php echo date('Y'); ?> - Qronos Inc.</p>
        </footer>
</div>